from flask import Flask, request, jsonify
from flask_restful import Resource, Api

import socket
import os
import time, threading
import commands
import fileinput
import json
#from settings import ports, lovelace_length



#object_name = "person"
#network_url = "rtsp://192.168.1.14:5540/ch0"
#camera_name = "camera1"
ports = 4500
lovelace_length = (("null",0))


app = Flask(__name__)

#stop the service 
@app.route('/stop/',methods = ['POST'])
  camera_name = request.args.get('camera','')

  global ports, lovelace_length

  with open('/usr/share/hassio/homeassistant/configuration.yaml', 'rb') as output, open('/home/camera/frigate/' + camera_name + '/cameras.yaml', 'rb') as input:
    filedata_in = input.read()
    fifledata_out = output.read()
    fifledata_out = fifledata_out.replace(filedata_in, '')


  with open('/usr/share/hassio/homeassistant/configuration.yaml', 'w') as file:
    file.write(fifledata_out)
  


  with open(r'/home/camera/frigate/configs/lovelace') as file:
    # The FullLoader parameter handles the conversion from YAML
    # scalar values to Python the dictionary format
    HA_configs  = json.load(file)
    #print(HA_configs)

  #lovelc_len = len(HA_configs['data']['config']['views'][0]['cards'])
  #new_len = ((camera_name, lovelc_len))
  #lovelace_length =  ((lovelace_length, ) + (new_len, )) 


  print(" BEFORE : ")
  print(lovelace_length)
  with open('/usr/share/hassio/homeassistant/.storage/lovelace', 'r') as file:
    HA_configs  = json.load(file)
  
  #settings.lovelace_length =  ((settings.lovelace_length, ) + (index, ))
  
    if lovelace_length[-1][0] == camera_name :
      print("LAST ELEMENT")
      index = len(HA_configs['data']['config']['views'][0]['cards'])
    #remove from lovelace the cards
      HA_configs['data']['config']['views'][0]['cards'].pop(index-1)
      HA_configs['data']['config']['views'][0]['cards'].pop(index-2)
    #remove from tuple the index
      temp=list(lovelace_length)
      temp.pop()
      lovelace_length = tuple(temp)
    else:
    #find the index of camera
      index_len = 0
      for x in lovelace_length:
        if x[0] == camera_name :
          index = x[1]
          break
        index_len = index_len + 1

    #remove from lovelace.length
      temp=list(lovelace_length)
      temp.pop(index_len)
      lovelace_length = tuple(temp)

    #remove from lovelace the cards
      HA_configs['data']['config']['views'][0]['cards'].pop(index-1)
      HA_configs['data']['config']['views'][0]['cards'].pop(index-2)
    
    #update the new indexes
      for x in lovelace_length:
        y=list(x)
        y[1] = y[1]-2
        x=tuple(y)
    

  print(" AFTER : ")
  print(lovelace_length)


  json_output = json.dumps(HA_configs)

  with open('/usr/share/hassio/homeassistant/.storage/lovelace', 'w') as file:
    file.write(json_output)



  cmd = 'sudo cp /usr/share/hassio/homeassistant/.storage/lovelace /home/camera/frigate/configs/lovelace'
  os.system(cmd)


  print("Restart Home-Assitant")

  cmd = 'sudo docker restart 425674f5d108'
  os.system(cmd) 

  time.sleep(30)

  print("Stop container service of " + camera_name)
  cmd = 'sudo docker rm -f ' + camera_name
  os.system(cmd)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')