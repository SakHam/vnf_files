import yaml
import json
with open(r'/home/camera/frigate/configs/lovelace') as file:
    # The FullLoader parameter handles the conversion from YAML
    # scalar values to Python the dictionary format
    HA_configs  = json.load(file)

    print(HA_configs)
    #configs["objects"]["filters"]["bottle"] = configs["objects"]["filters"]["person"]
    print(type(HA_configs))
    #configs["cameras"] = "camera2"
    #print(configs)
    #configs['cameras']['camera2'] = configs['cameras']['camera1']
    #configs['cameras']['camera2']['objects']['filters']['bottle'] =    configs['cameras']['camera2']['objects']['filters']['person']

    #print(test.values()[0])
with open(r'/home/camera/frigate/configs/Cards_stream') as file:
    # The FullLoader parameter handles the conversion from YAML
    # scalar values to Python the dictionary format
    card_configs1  = json.load(file)

    print(card_configs1)
    #configs["objects"]["filters"]["bottle"] = configs["objects"]["filters"]["person"]
    print(type(card_configs1))
#with open(r'/home/camera/frigate/lovelace', 'w') as file:
    #data  = json.dump(configs, file)
with open(r'/home/camera/frigate/configs/Cards_image') as file:
    # The FullLoader parameter handles the conversion from YAML
    # scalar values to Python the dictionary format
    card_configs2  = json.load(file)

    print(card_configs2)
    #configs["objects"]["filters"]["bottle"] = configs["objects"]["filters"]["person"]
    print(type(card_configs2))

print(len(HA_configs['data']['config']['views'][0]['cards']))
index =len(HA_configs['data']['config']['views'][0]['cards'])
#HA_configs['data']['config']['views'][0]['cards'][index] = card_configs1
#HA_configs['data']['config']['views'][0]['cards'][index+1] = card_configs2
HA_configs['data']['config']['views'][0]['cards'].append(card_configs1)
HA_configs['data']['config']['views'][0]['cards'].append(card_configs2)
#print(HA_configs)
print(len(HA_configs['data']['config']['views'][0]['cards']))
index =len(HA_configs['data']['config']['views'][0]['cards'])

