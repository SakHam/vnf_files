from flask import Flask, request, jsonify
from flask_restful import Resource, Api

import socket
import os
import time, threading
import commands
import fileinput
import json
#import settings


#object_name = "bottle"
#network_url = "rtsp://192.168.1.14:5540/ch0"
#camera_name = "camera2"
ports = 4500
lovelace_length = [["null",0]]

#lovelace_length = (("null",0),("camera1",7),("camera2",9))


app = Flask(__name__)

#3 options, load, start and stop the new service 
@app.route('/start/',methods = ['POST'])
def start():
  camera_name = request.args.get('camera_name','')
  network_url = request.args.get('network_url','')
  object_name = request.args.get('object_name','')  


  global ports, lovelace_length
  docker_ports = str(ports) + ':' + str(ports)
  print("Frigate Camera Settings Configurations")
  with open('/home/camera/frigate/configs/config.yml', 'r') as file :
    filedata = file.read()

# Replace the target string
  filedata = filedata.replace('person', object_name)
  filedata = filedata.replace('network_url', network_url)
  filedata = filedata.replace('name_cam', camera_name)
  filedata = filedata.replace('port_web', str(ports))
  cmd = 'mkdir -m 777 "/home/camera/frigate/"' + camera_name
  os.system(cmd)

# Write the file out again
  with open('/home/camera/frigate/' + camera_name + '/config.yml', 'w') as file:
    file.write(filedata)

#########
#with open('/home/camera/frigate/configs/config.yml', 'r') as file :
  #filedata = file.read()

# Replace the target string
#filedata = filedata.replace('person', object_name)
#########
  time.sleep(2)

  print("Home-Assitant Camera Settings Configurations")
  with open('/usr/share/hassio/homeassistant/configuration.yaml', 'a') as output, open('/home/camera/frigate/configs/cameras.yaml', 'rb') as input:
    filedata = input.read()
    filedata = filedata.replace('id_name', camera_name)
    filedata = filedata.replace('topic_camera', 'frigate/' + camera_name + '/' + object_name + '/snapshot')
    filedata = filedata.replace('id_unq', 'image.' + camera_name)
    filedata = filedata.replace('stat_topic', 'frigate/' + camera_name + '/' + object_name)
    output.write('\n')	
    output.write(filedata)

  with open('/home/camera/frigate/' + camera_name + '/cameras.yaml', 'w') as file:
    file.write(filedata)

  time.sleep(2)

  print("Home-Assitant Cards Camera Settings Configurations")
  with open('/home/camera/frigate/configs/Cards_stream', 'r') as file :
    filedata = file.read()

# Replace the target string
  filedata = filedata.replace('name_cam', camera_name)
  filedata = filedata.replace('ports', str(ports))


# Write the file out again
  with open('/home/camera/frigate/' + camera_name + '/Cards_stream', 'w') as file:
    file.write(filedata)

  with open('/home/camera/frigate/configs/Cards_image', 'r') as file :
    filedata = file.read()

# Replace the target string
  filedata = filedata.replace('name_cam', camera_name)


# Write the file out again
  with open('/home/camera/frigate/' + camera_name + '/Cards_image', 'w') as file:
    file.write(filedata)



  time.sleep(2)


  print("Update Lovelace file")


  with open(r'/home/camera/frigate/configs/lovelace') as file:
    # The FullLoader parameter handles the conversion from YAML
    # scalar values to Python the dictionary format
    HA_configs  = json.load(file)




  with open(r'/home/camera/frigate/' + camera_name + '/Cards_stream') as file:
    # The FullLoader parameter handles the conversion from YAML
    # scalar values to Python the dictionary format
    card_configs1  = json.load(file)

  with open(r'/home/camera/frigate/' + camera_name + '/Cards_image') as file:
    # The FullLoader parameter handles the conversion from YAML
    # scalar values to Python the dictionary format
    card_configs2  = json.load(file)

  HA_configs['data']['config']['views'][0]['cards'].append(card_configs1)
  HA_configs['data']['config']['views'][0]['cards'].append(card_configs2)



  print(" lovelace_length BEFORE : ")
  print(lovelace_length)
  lovelc_len = len(HA_configs['data']['config']['views'][0]['cards'])
  new_len = ((camera_name, lovelc_len))
  #lovelace_length_temp = list(lovelace_length)
  #lovelace_length_temp.append(new_len)
  #lovelace_length = tuple(lovelace_length_temp)
  lovelace_length.append(new_len)
  print(" lovelace_length AFTER : ")
  print(lovelace_length)
  json_output = json.dumps(HA_configs)
  

  with open('/usr/share/hassio/homeassistant/.storage/lovelace', 'w') as file:
    file.write(json_output)

  cmd = 'sudo cp /usr/share/hassio/homeassistant/.storage/lovelace /home/camera/frigate/configs/lovelace'
  os.system(cmd)

  time.sleep(2)





  print("Restart Home-Assitant")

  cmd = 'sudo docker restart 425674f5d108'
  os.system(cmd)

  time.sleep(30)
  print("Run Object Detection Service  at Ports : " + str(ports))
  cmd = 'sudo docker run -d --name ' + camera_name + ' --rm --privileged --shm-size=1g -v /dev/bus/usb:/dev/bus/usb -v /home/camera/frigate/' + camera_name + ':/config:ro -p ' + docker_ports + ' -e RTSP_PASSWORD="admin" frigate:latest'
  os.system(cmd)

  ports = ports + 1
  print("Update Ports : " + str(ports))
  time.sleep(2)


  return "Service " + camera_name + "Started"




#stop the service 
@app.route('/stop/',methods = ['POST'])
def stop():
  camera_name = request.args.get("camera_name","")

  global ports, lovelace_length

  with open('/usr/share/hassio/homeassistant/configuration.yaml', 'rb') as output, open('/home/camera/frigate/' + camera_name + '/cameras.yaml', 'rb') as input:
    filedata_in = input.read()
    fifledata_out = output.read()
    fifledata_out = fifledata_out.replace(filedata_in, '')


  with open('/usr/share/hassio/homeassistant/configuration.yaml', 'w') as file:
    file.write(fifledata_out)
  


  #with open(r'/home/camera/frigate/configs/lovelace') as file:
    # The FullLoader parameter handles the conversion from YAML
    # scalar values to Python the dictionary format
    #HA_configs  = json.load(file)


  with open('/usr/share/hassio/homeassistant/.storage/lovelace', 'r') as file:
    HA_configs  = json.load(file)
 

  keep_going = True
  index = 0
  while keep_going:
    temp = str(HA_configs['data']['config']['views'][0]['cards'][index])
    if (temp.find(camera_name) != -1): 
      print("Find name : " + camera_name) 
      print("At index : ")
      print(index)
      keep_going = False
    else:
      index = index + 1
  
  HA_configs['data']['config']['views'][0]['cards'].pop(index)

  keep_going = True
  index = 0
  while keep_going:
    temp = str(HA_configs['data']['config']['views'][0]['cards'][index])
    if temp.find(camera_name) != -1 :
      print("Find name : " + camera_name) 
      print("At index : ")
      print(index)
      keep_going = False
    else:
      index = index + 1
  
  HA_configs['data']['config']['views'][0]['cards'].pop(index)


  ''' 
  #settings.lovelace_length =  ((settings.lovelace_length, ) + (index, ))
  print(lovelace_length)
  if lovelace_length[-1][0] == camera_name :
    print(" BEFORE : ")
    print(lovelace_length)
    print("LAST ELEMENT")
    index = len(HA_configs['data']['config']['views'][0]['cards'])
    #remove from lovelace the cards
    HA_configs['data']['config']['views'][0]['cards'].pop(index-1)
    HA_configs['data']['config']['views'][0]['cards'].pop(index-2)
    #remove from tuple the index
    #temp=list(lovelace_length)
    #temp.pop()
    #lovelace_length = tuple(temp)

    lovelace_length.pop()
  else:
    print(" BEFORE : ")
    print(lovelace_length)
    print("MEDIAN ELEMENT")
    #find the index of camera_name

    #lovelace_length_temp = list(lovelace_length)
    index_len = 0
    for x in lovelace_length:
      if x[0] == camera_name :
        index = x[1]
        break
      index_len = index_len + 1

    #for subarray in lovelace_length_temp:
      #if camera_name in subarray:
        #print(lovelace_length_temp.index(subarray))
        #index_len = ovelace_length_temp.index(subarray)
    #print("index len : ")
    #print(index_len)

  
    #remove from lovelace.length
    #temp=list(lovelace_length)
    #temp.pop(index_len)
    #lovelace_length = tuple(temp)
    lovelace_length.pop(index_len)
    #remove from lovelace the cards
    HA_configs['data']['config']['views'][0]['cards'].pop(index-1)
    HA_configs['data']['config']['views'][0]['cards'].pop(index-2)
    
    #update the new indexes
    temp = list() 
    for x in lovelace_length:
      temp1=list(x)
      temp1[1] = temp1[1] - 2
      temp.append(temp1)
      
      
    #lovelace_length = tuple(temp)
    lovelace_length = temp
  print(" AFTER : ")
  print(lovelace_length)

  '''

  json_output = json.dumps(HA_configs) 

  with open('/usr/share/hassio/homeassistant/.storage/lovelace', 'w') as file:
    file.write(json_output)



  cmd = 'sudo cp /usr/share/hassio/homeassistant/.storage/lovelace /home/camera/frigate/configs/lovelace'
  os.system(cmd)


  print("Restart Home-Assitant")

  cmd = 'sudo docker restart 425674f5d108'
  os.system(cmd) 

  time.sleep(30)

  print("Stop container service of " + camera_name)
  cmd = 'sudo docker rm -f ' + camera_name
  os.system(cmd)
  return "Service " + camera_name + "Stopped"
  
if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')