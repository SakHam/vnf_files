from flask import Flask, request, jsonify
from flask_restful import Resource, Api

import socket
import os
import time, threading
import commands
import fileinput
import json
#import settings

ports = 4500
automation_id = 1584118258158
app = Flask(__name__)

#3 options, load, start and stop the new service 
@app.route('/stop/',methods = ['POST'])
def stop():
  camera_name = request.args.get('camera_name','')
  object_name = request.args.get('object_name','')  
  network_url = request.args.get('network_url','')
  global ports, automation_id
  docker_ports = str(ports) + ':' + str(ports)
  print("Frigate Camera Settings Configurations")
  with open('/home/camera/frigate/configs/config.yml', 'r') as file :
    filedata = file.read()

# Replace the target string
  filedata = filedata.replace('person', object_name)
  filedata = filedata.replace('network_url', network_url)
  filedata = filedata.replace('name_cam', camera_name)
  filedata = filedata.replace('port_web', str(ports))
  cmd = 'mkdir -m 777 "/home/camera/frigate/"' + camera_name
  os.system(cmd)

# Write the file out again
  with open('/home/camera/frigate/' + camera_name + '/config.yml', 'w') as file:
    file.write(filedata)


  time.sleep(2)



  print("Home-Assitant Camera Settings Configurations")
### configure input number 

  with open('/usr/share/hassio/homeassistant/configuration.yaml', 'r+') as output, open('/home/camera/frigate/configs/input_number_template.yaml', 'rb') as input:
    fileinput = input.read() 
    fileinput = fileinput.replace('camer_name', camera_name)
    #print(file1)
    filedataout = output.read() 
    filedataout = filedataout.replace('input_number:', 'input_number:\n' + str(fileinput))
    #for line in output:
      #if "input_number:" in line :
        #line = line.rstrip()
        #line = line.replace(line,line + '\n' + filedata)
        #break
    #new_file_content = ""
    #for line in output:
      #stripped_line = line.strip()
      #new_line = stripped_line.replace('input_number:', 'input_number:' + '\n  ' + str(filedata))
      #new_file_content += new_line +"\n"
    #output.close()
  with open('/usr/share/hassio/homeassistant/configuration.yaml', 'w') as file:
    file.write(filedataout)
  #writing_file = open("/usr/share/hassio/homeassistant/configuration.yaml", "w")
  #writing_file.write(new_file_content)
  #writing_file.close()

  with open('/home/camera/frigate/' + camera_name + '/input_number.yaml', 'w') as file:
    file.write(fileinput)

  time.sleep(2)



  print("Home-Assitant Camera Settings Configurations")

  with open('/usr/share/hassio/homeassistant/configuration.yaml', 'a') as output, open('/home/camera/frigate/configs/cameras.yaml', 'rb') as input:
    filedata = input.read()
    filedata = filedata.replace('camer_name', camera_name)
    filedata = filedata.replace('id_name', camera_name)
    filedata = filedata.replace('topic_camera', 'frigate/' + camera_name + '/' + object_name + '/snapshot')
    filedata = filedata.replace('id_unq', 'image.' + camera_name)
    filedata = filedata.replace('stat_topic', 'frigate/' + camera_name + '/' + object_name)
    filedata = filedata.replace('stat_topc_event', 'frigate/' + camera_name + '/' + object_name)
    filedata = filedata.replace('id_unq_event', camera_name + ".event")
    filedata = filedata.replace('id_name_event', camera_name + ".event")
    filedata = filedata.replace('events_unit', camera_name + ".event")
    filedata = filedata.replace('sum_topic', 'frigate/' + camera_name + '/' + object_name + '/sum')
    filedata = filedata.replace('objn', object_name)    
    output.write('\n')	
    output.write(filedata)

  with open('/home/camera/frigate/' + camera_name + '/cameras.yaml', 'w') as file:
    file.write(filedata)

  return "Service " + camera_name + " Stopped"
  
if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')