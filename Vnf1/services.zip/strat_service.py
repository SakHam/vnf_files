from flask import Flask, request, jsonify
from flask_restful import Resource, Api

import socket
import os
import time, threading
import commands
import fileinput
import json
#import settings


#object_name = "bottle"
#network_url = "rtsp://192.168.1.14:5540/ch0"
#camera_name = "camera2"
ports = 4500
lovelace_length = (("null",0))





app = Flask(__name__)

#3 options, load, start and stop the new service 
@app.route('/start/',methods = ['POST'])
  camera_name = request.args.get('camera','')
  network_url = request.args.get('network_url','')
  object_name = request.args.get('object_name','')  


  global ports, lovelace_length
  print("Frigate Camera Settings Configurations")
  with open('/home/camera/frigate/configs/config.yml', 'r') as file :
    filedata = file.read()

# Replace the target string
  filedata = filedata.replace('person', object_name)
  filedata = filedata.replace('network_url', network_url)
  filedata = filedata.replace('name_cam', camera_name)
  filedata = filedata.replace('port_web', str(ports))
  cmd = 'mkdir -m 777 "/home/camera/frigate/"' + camera_name
  os.system(cmd)

# Write the file out again
  with open('/home/camera/frigate/' + camera_name + '/config.yml', 'w') as file:
    file.write(filedata)

#########
#with open('/home/camera/frigate/configs/config.yml', 'r') as file :
  #filedata = file.read()

# Replace the target string
#filedata = filedata.replace('person', object_name)
#########
  time.sleep(2)

  print("Home-Assitant Camera Settings Configurations")
  with open('/usr/share/hassio/homeassistant/configuration.yaml', 'a') as output, open('/home/camera/frigate/configs/cameras.yaml', 'rb') as input:
    filedata = input.read()
    filedata = filedata.replace('id_name', camera_name)
    filedata = filedata.replace('topic_camera', 'frigate/' + camera_name + '/' + object_name + '/snapshot')
    filedata = filedata.replace('id_unq', 'image.' + camera_name)
    filedata = filedata.replace('stat_topic', 'frigate/' + camera_name + '/' + object_name)
# Replace the target string
    #filedata = filedata.replace('camera', camera_name)
    #while True:
        #data = input.read(100000)
        #if data == '':  # end of file reached
            #break
    output.write('\n')	
    output.write(filedata)

  with open('/home/camera/frigate/' + camera_name + '/cameras.yaml', 'w') as file:
    file.write(filedata)

  time.sleep(2)

  print("Home-Assitant Cards Camera Settings Configurations")
  with open('/home/camera/frigate/configs/Cards_stream', 'r') as file :
    filedata = file.read()

# Replace the target string
  filedata = filedata.replace('name_cam', camera_name)
  filedata = filedata.replace('ports', str(ports))


# Write the file out again
  with open('/home/camera/frigate/' + camera_name + '/Cards_stream', 'w') as file:
    file.write(filedata)

  with open('/home/camera/frigate/configs/Cards_image', 'r') as file :
    filedata = file.read()

# Replace the target string
  filedata = filedata.replace('name_cam', camera_name)


# Write the file out again
  with open('/home/camera/frigate/' + camera_name + '/Cards_image', 'w') as file:
    file.write(filedata)



  time.sleep(2)


  print("Update Lovelace file")


  with open(r'/home/camera/frigate/configs/lovelace') as file:
    # The FullLoader parameter handles the conversion from YAML
    # scalar values to Python the dictionary format
    HA_configs  = json.load(file)


    #print(HA_configs)
    #print(type(HA_configs))



  with open(r'/home/camera/frigate/' + camera_name + '/Cards_stream') as file:
    # The FullLoader parameter handles the conversion from YAML
    # scalar values to Python the dictionary format
    card_configs1  = json.load(file)
    #print(card_configs1)
    #print(type(card_configs1))

  with open(r'/home/camera/frigate/' + camera_name + '/Cards_image') as file:
    # The FullLoader parameter handles the conversion from YAML
    # scalar values to Python the dictionary format
    card_configs2  = json.load(file)
    print(card_configs2)

  HA_configs['data']['config']['views'][0]['cards'].append(card_configs1)
  HA_configs['data']['config']['views'][0]['cards'].append(card_configs2)



  print(" lovelace_length BEFORE : ")
  print(lovelace_length)
  lovelc_len = len(HA_configs['data']['config']['views'][0]['cards'])
  new_len = ((camera_name, lovelc_len))
  lovelace_length_temp = list(lovelace_length)
  lovelace_length_temp.append(new_len)
  lovelace_length = tuple(lovelace_length_temp)

  print(" lovelace_length AFTER : ")
  print(lovelace_length)
  json_output = json.dumps(HA_configs)
  

  with open('/usr/share/hassio/homeassistant/.storage/lovelace', 'w') as file:
    file.write(json_output)

  cmd = 'sudo cp /usr/share/hassio/homeassistant/.storage/lovelace /home/camera/frigate/configs/lovelace'
  os.system(cmd)

  time.sleep(2)





  print("Restart Home-Assitant")

  cmd = 'sudo docker restart 425674f5d108'
  os.system(cmd)

  time.sleep(30)
  cmd = 'sudo docker run --name ' + camera_name + ' --rm --privileged --shm-size=1g -v /dev/bus/usb:/dev/bus/usb -v /home/camera/frigate/' + camera_name + ':/config:ro -p ' + docker_ports + ' -e RTSP_PASSWORD="admin" frigate:latest'

  print("Update Ports")
  update_ports = ports + 1
#update_ports = 'ports = ' + str(ports)
#with open('/home/camera/services/ports.py', 'w') as file:
  #file.write(update_ports)
  ports = update_ports
  time.sleep(2)

  print("Run Object Detection Service")
  os.system(cmd)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')

