# USAGE
# python yolo_video.py --input videos/airport.mp4 --output output/airport_output.avi --yolo yolo-coco

# import the necessary packages
import numpy as np
import argparse
import imutils
import time
import cv2
import os
from flask import Flask, Response, make_response, jsonify, request

# construct the argument parse and parse the arguments


global camera_name,inpt,obj_name


# loop over frames from the video file stream
def main():
		app = Flask(__name__)

		@app.route('/inputs/',methods = ['POST'])

		def inputs():
			global camera_name,inpt,obj_name
			camera_name = request.args.get('camera_name','')
			inpt = request.args.get('network_url','')
			obj_name = request.args.get('object_name','') 
			print("Inputs : ")
			print(camera_name)
			print(inpt)
			print(obj_name)
			#return mjpeg_feed(cam_name,inpt,obj_name)
			return "Inputs OK"

		@app.route('/<cam_name>')
		
		def mjpeg_feed(cam_name):
			print("Inputs : ")
			global camera_name,inpt,obj_name
			cam_name= camera_name
			print(camera_name)
			print(inpt)
			print(obj_name)
			#inpt = "rtsp://192.168.1.5:5540/ch0"
			#otpt = "output/overpass.avi"
			#cam_name = "camera1"
			#obj_name = "person"
			yolo = "yolo-coco"
			confidence1 = 0.5
			threshold = 0.3
			# load the COCO class labels our YOLO model was trained on
			labelsPath = os.path.sep.join([yolo, "coco.names"])
			LABELS = open(labelsPath).read().strip().split("\n")

			# initialize a list of colors to represent each possible class label
			np.random.seed(42)
			COLORS = np.random.randint(0, 255, size=(len(LABELS), 3),
				dtype="uint8")

			# derive the paths to the YOLO weights and model configuration
			weightsPath = os.path.sep.join([yolo, "yolov3-tiny.weights"])
			configPath = os.path.sep.join([yolo, "yolov3-tiny.cfg"])

			# load our YOLO object detector trained on COCO dataset (80 classes)
			# and determine only the *output* layer names that we need from YOLO
			print("[INFO] loading YOLO from disk...")
			net = cv2.dnn.readNetFromDarknet(configPath, weightsPath)
			ln = net.getLayerNames()
			ln = [ln[i[0] - 1] for i in net.getUnconnectedOutLayers()]
			vs = cv2.VideoCapture(inpt)
			# initialize the video stream, pointer to output video file, and
			# frame dimensions
			writer = None
			(W, H) = (None, None)

			# try to determine the total number of frames in the video file
			try:
				prop = cv2.cv.CV_CAP_PROP_FRAME_COUNT if imutils.is_cv2() \
					else cv2.CAP_PROP_FRAME_COUNT
				total = int(vs.get(prop))
				print("[INFO] {} total frames in video".format(total))

			# an error occurred while trying to determine the total
			# number of frames in the video file
			except:
				print("[INFO] could not determine # of frames in video")
				print("[INFO] no approx. completion time can be provided")
				total = -1			
			fps = 6
			height = 360

			return Response(imagestream(cam_name,fps, height,net,ln,confidence1,threshold,inpt,COLORS,LABELS,vs,W,writer),
                            	mimetype='multipart/x-mixed-replace; boundary=frame')


		def imagestream(cam_name,fps, height,net,ln,confidence1,threshold,inpt,COLORS,LABELS,vs,W,writer):
			while True:
				# read the next frame from the file
				#print("Spank!")
				(grabbed, frame) = vs.read()
				#cv2.imshow('VIDEO', frame)
				# if the frame was not grabbed, then we have reached the end
				# of the stream
				if not grabbed:
					break

				# if the frame dimensions are empty, grab them
				if W is None or H is None:
					(H, W) = frame.shape[:2]

				# construct a blob from the input frame and then perform a forward
				# pass of the YOLO object detector, giving us our bounding boxes
				# and associated probabilities
				blob = cv2.dnn.blobFromImage(frame, 1 / 255.0, (416, 416),
					swapRB=True, crop=False)
				net.setInput(blob)
				start = time.time()
				layerOutputs = net.forward(ln)
				end = time.time()
				#print(len(layerOutputs))
				# initialize our lists of detected bounding boxes, confidences,
				# and class IDs, respectively
				boxes = []
				confidences = []
				classIDs = []

				# loop over each of the layer outputs
				for output in layerOutputs:
					# loop over each of the detections
					k=0
					for detection in output:
						#print("LENGHT")
						#print(k)
						#k=k+1
						#print("LENGHT")
						#print(detection[5:].shape)
						# extract the class ID and confidence (i.e., probability)
						# of the current object detection
						#print("LENGHT")
						#print(len(detection[5:]))


						scores = detection[5:]
						classID = np.argmax(scores)
						confidence = scores[classID]

						#my code
						#confidence = scores[60]
						#if classID==56:
							#print("first")
							#print(classID)
						#confidence = scores[56]
			




						# filter out weak predictions by ensuring the detected
						# probability is greater than the minimum probability
						if confidence > confidence1:
							print("classID")
							print(classID)
							#print("OUTPUT")
							#print(output)
							#print("--------------------------")
							print("--------------------------")
							#print("DETECTION")
							#print(detection)
							#print("--------------------------")
							print("--------------------------")
							# scale the bounding box coordinates back relative to
							# the size of the image, keeping in mind that YOLO
							# actually returns the center (x, y)-coordinates of
							# the bounding box followed by the boxes' width and
							# height
							box = detection[0:4] * np.array([W, H, W, H])
							(centerX, centerY, width, height) = box.astype("int")

							# use the center (x, y)-coordinates to derive the top
							# and and left corner of the bounding box
							x = int(centerX - (width / 2))
							y = int(centerY - (height / 2))

							# update our list of bounding box coordinates,
							# confidences, and class IDs
							boxes.append([x, y, int(width), int(height)])
							confidences.append(float(confidence))
							classIDs.append(classID)


				
				# apply non-maxima suppression to suppress weak, overlapping
				# bounding boxes
				idxs = cv2.dnn.NMSBoxes(boxes, confidences, confidence1,
					threshold)

				# ensure at least one detection exists
				if len(idxs) > 0:
					# loop over the indexes we are keeping
					for i in idxs.flatten():
						# extract the bounding box coordinates
						(x, y) = (boxes[i][0], boxes[i][1])
						(w, h) = (boxes[i][2], boxes[i][3])
						#print(classIDs[i])
						#print("SPANK!!!!!")
						# draw a bounding box rectangle and label on the frame

						color = [int(c) for c in COLORS[classIDs[i]]]
						cv2.rectangle(frame, (x, y), (x + w, y + h), color, 2)
						text = "{}: {:.4f}".format(LABELS[classIDs[i]],
							confidences[i])
						cv2.putText(frame, text, (x, y - 5),
							cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
						

						

					

		    		# max out at specified FPS
				time.sleep(1/fps)
		    		#frame = object_processor.get_current_frame(camera1)
				if frame is None:
					print("None Frame")
					frame = np.zeros((height,int(height*16/9),3), np.uint8)

				frame = cv2.resize(frame, dsize=(int(height*16/9), height), interpolation=cv2.INTER_LINEAR)
				frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)

				ret, jpg = cv2.imencode('.jpg', frame)
				yield (b'--frame\r\n'
					b'Content-Type: image/jpeg\r\n\r\n' + jpg.tobytes() + b'\r\n\r\n')
				#print("Again")

		app.run(host='0.0.0.0', debug=False)

if __name__ == '__main__':
    main()

# release the file pointers
print("[INFO] cleaning up...")

